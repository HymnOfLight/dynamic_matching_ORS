"""Test suite for audit_lab.

Cross-validation is the load-bearing part (project methodology):
  T1  Blossom vs bitmask-DP on random + structured small graphs;
  T2  local RGMM oracle vs global greedy, edge by edge, across all three
      rank-source families;
  T3  k-wise rank family sanity (distinct keys, rough uniformity);
  T4  E2 adversarial path costs exactly m evaluations on the head query;
  T5  E5 plant validity: disjoint from probes, a matching, size bound;
  T6  E4 recourse arithmetic on a hand-checked tiny path.

Run:  python3 tests.py
"""

from __future__ import annotations

import random
import unittest

from auditlib.graphs import Graph, complement_pairs, gnp_graph, path_graph
from auditlib.matching import (
    greedy_maximal_matching,
    is_maximal_matching,
    maximum_matching,
    maximum_matching_size_bruteforce,
)
from auditlib.ranks import FixedRanks, FullyRandomRanks, KWiseRanks
from auditlib.rgmm import GreedyMatchingOracle


class T1BlossomCrossValidation(unittest.TestCase):
    def test_random_graphs(self) -> None:
        rng = random.Random(20260611)
        for trial in range(300):
            n = rng.randint(2, 14)
            p = rng.uniform(0.1, 0.6)
            edges = [
                (u, v)
                for (u, v) in complement_pairs(n, set())
                if rng.random() < p
            ]
            g = Graph(n, edges)
            blossom_size, match = maximum_matching(g)
            dp_size = maximum_matching_size_bruteforce(g)
            self.assertEqual(
                blossom_size, dp_size,
                msg=f"trial {trial}: n={n} edges={edges}",
            )
            self._check_matching(g, match, blossom_size)

    def test_structured_graphs(self) -> None:
        # Odd cycles C_{2k+1}: mu = k.
        for k in range(1, 8):
            n = 2 * k + 1
            edges = sorted(tuple(sorted((i, (i + 1) % n))) for i in range(n))
            g = Graph(n, edges)
            self.assertEqual(maximum_matching(g)[0], k)
        # Petersen graph: mu = 5.
        outer = [(i, (i + 1) % 5) for i in range(5)]
        inner = [(5 + i, 5 + (i + 2) % 5) for i in range(5)]
        spokes = [(i, i + 5) for i in range(5)]
        pet = Graph(10, sorted(tuple(sorted(e)) for e in outer + inner + spokes))
        self.assertEqual(maximum_matching(pet)[0], 5)
        # Complete graphs: mu = floor(n/2).
        for n in range(2, 11):
            g = Graph(n, complement_pairs(n, set()))
            self.assertEqual(maximum_matching(g)[0], n // 2)

    def _check_matching(self, g: Graph, match: list[int], size: int) -> None:
        adj = {tuple(sorted(e)) for e in g.edges}
        count = 0
        for v, u in enumerate(match):
            if u == -1:
                continue
            self.assertEqual(match[u], v)
            self.assertIn(tuple(sorted((u, v))), adj)
            count += 1
        self.assertEqual(count, 2 * size)


class T2OracleVsGlobalGreedy(unittest.TestCase):
    def test_all_rank_sources(self) -> None:
        rng = random.Random(7)
        for trial in range(120):
            n = rng.randint(2, 40)
            g = gnp_graph(n, rng.uniform(1.0, 6.0), rng)
            if g.m == 0:
                continue
            sources = [
                FullyRandomRanks(random.Random(rng.getrandbits(64))),
                KWiseRanks(k=rng.choice([2, 3, 4]),
                           rng=random.Random(rng.getrandbits(64))),
                FixedRanks({e: (e * 2654435761) % (1 << 32) for e in range(g.m)}),
            ]
            for src in sources:
                truth = greedy_maximal_matching(g, src.key)
                self.assertTrue(is_maximal_matching(g, truth))
                oracle = GreedyMatchingOracle(g, src.key)
                for e in range(g.m):
                    self.assertEqual(
                        oracle.edge_in_matching(e), e in truth,
                        msg=f"trial {trial} src={src.describe()} edge={e}",
                    )


class T3KWiseSanity(unittest.TestCase):
    def test_distinct_keys_and_rough_uniformity(self) -> None:
        rng = random.Random(99)
        src = KWiseRanks(k=2, rng=rng)
        keys = [src.key(e) for e in range(5000)]
        self.assertEqual(len(set(keys)), 5000)  # strict total order
        # Rough marginal uniformity: bucket the values into 10 bins.
        buckets = [0] * 10
        for value, _ in keys:
            buckets[value * 10 // src.prime] += 1
        for b in buckets:  # crude 3-sigma band around 500
            self.assertGreater(b, 350)
            self.assertLess(b, 650)


class T4AdversarialPathCost(unittest.TestCase):
    def test_head_query_costs_m(self) -> None:
        for m in (10, 257, 4096):
            g = path_graph(m)
            oracle = GreedyMatchingOracle(
                g, FixedRanks({e: m - e for e in range(m)}).key
            )
            result = oracle.edge_in_matching(0)
            self.assertEqual(oracle.evaluations, m)
            # Membership of the head edge alternates with parity of m:
            # the lowest-rank edge is the tail; greedy picks every other
            # edge backwards, so edge 0 is matched iff m is odd.
            self.assertEqual(result, m % 2 == 1)


class T5PlantValidity(unittest.TestCase):
    def test_plant_disjoint_and_large(self) -> None:
        n = 40
        pairs = complement_pairs(n, set())
        random.Random(0).shuffle(pairs)
        threshold = (n // 2) * (n // 2 - 1) // 2  # C(n/2, 2), n even
        for budget in (n, threshold - 1):
            probe_set = set(pairs[:budget])
            comp = Graph(n, complement_pairs(n, probe_set))
            size, match = maximum_matching(comp)
            self.assertGreaterEqual(size, n // 4)  # Lemma 3.6 guarantee
            for v in range(n):
                if match[v] != -1:
                    self.assertNotIn(tuple(sorted((v, match[v]))), probe_set)


class T6RecourseArithmetic(unittest.TestCase):
    def test_tiny_path_flip(self) -> None:
        # Path with 4 edges, ranks 0..3: greedy = {e0, e2}.  Remove e0:
        # greedy = {e1, e3}.  Symmetric difference = 4 = full flip.
        g = path_graph(4)
        key = FixedRanks({e: e for e in range(4)}).key
        before = greedy_maximal_matching(g, key, active={0, 1, 2, 3})
        self.assertEqual(before, {0, 2})
        after = greedy_maximal_matching(g, key, active={1, 2, 3})
        self.assertEqual(after, {1, 3})
        self.assertEqual(len(before ^ after), 4)


if __name__ == "__main__":
    unittest.main(verbosity=2)
