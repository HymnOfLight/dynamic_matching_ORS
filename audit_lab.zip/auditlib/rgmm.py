"""Local greedy-maximal-matching (RGMM) oracle and sampling estimators.

This is a faithful, instrumented model of the *sublinear oracle layer*
that the randomness audit (plan §2.4, Task A0) identifies inside the
polylog-update pipelines [BKSW23, Beh23, ABR24] via [Beh21]:

* ``GreedyMatchingOracle.edge_in_matching(e)`` answers "is edge ``e`` in
  the greedy maximal matching induced by the given ranks?" by recursing
  only on *lower-rank adjacent* edges -- the local computation whose
  expected cost under fully random ranks is what randomness buys
  (audit row R2), and whose worst case under fixed ranks is Theta(m)
  (experiment E2).
* ``estimate_mm_size_by_vertex_sampling`` is the Monte-Carlo size
  estimator built on top of the oracle (audit row R1): sample vertices,
  test matched-ness locally, rescale.

Instrumentation: ``oracle.evaluations`` counts distinct edge-oracle
values computed (memo entries created).  This is the implementation-
independent locality metric used by E1--E3.
"""

from __future__ import annotations

import random
from typing import Callable

from .graphs import Graph

RankKey = Callable[[int], object]


class GreedyMatchingOracle:
    """Memoised local oracle for rank-driven greedy maximal matching.

    Semantics (defines greedy MM): ``e`` is in the matching iff no
    adjacent edge of strictly lower rank is in the matching.  The
    evaluation is iterative (explicit stack) so adversarial instances
    with Theta(m)-deep dependency chains (E2) do not hit Python's
    recursion limit.
    """

    def __init__(self, graph: Graph, rank_key: RankKey) -> None:
        self.graph = graph
        self.rank_key = rank_key
        self.memo: dict[int, bool] = {}
        self._lower_cache: dict[int, list[int]] = {}
        self.evaluations = 0  # locality metric: memo entries created

    # ------------------------------------------------------------------
    def _lower_neighbors(self, e: int) -> list[int]:
        """Adjacent edges of strictly lower rank, sorted by rank (asc)."""
        cached = self._lower_cache.get(e)
        if cached is not None:
            return cached
        rk = self.rank_key
        my_rank = rk(e)
        lows = [f for f in self.graph.adjacent_edges(e) if rk(f) < my_rank]
        lows.sort(key=rk)
        self._lower_cache[e] = lows
        return lows

    def edge_in_matching(self, root: int) -> bool:
        memo = self.memo
        if root in memo:
            return memo[root]
        # ptr[e] = index of the next lower-rank neighbour to inspect.
        ptr: dict[int, int] = {}
        stack: list[int] = [root]
        while stack:
            e = stack[-1]
            if e in memo:  # resolved while waiting on the stack
                stack.pop()
                continue
            lows = self._lower_neighbors(e)
            i = ptr.get(e, 0)
            verdict: bool | None = None
            while i < len(lows):
                f = lows[i]
                f_val = memo.get(f)
                if f_val is None:
                    ptr[e] = i  # resume here after f resolves
                    stack.append(f)
                    break
                if f_val:  # a lower-rank neighbour is matched
                    verdict = False
                    break
                i += 1
            else:
                verdict = True  # no lower-rank neighbour is matched
            if verdict is not None:
                memo[e] = verdict
                self.evaluations += 1
                stack.pop()
        return memo[root]

    # ------------------------------------------------------------------
    def vertex_matched(self, v: int) -> bool:
        """Is vertex ``v`` matched in the greedy MM?  (Local check.)

        Inspects incident edges in ascending rank -- the cheap-first
        order used in the sublinear-algorithm analyses.
        """
        incident = sorted(self.graph.incident_edges(v), key=self.rank_key)
        return any(self.edge_in_matching(e) for e in incident)


# ======================================================================
# Sampling estimators on top of the oracle (audit row R1)
# ======================================================================

def estimate_mm_size_by_vertex_sampling(
    oracle: GreedyMatchingOracle,
    num_samples: int,
    rng: random.Random,
) -> float:
    """Monte-Carlo estimate of |greedy MM| via vertex sampling.

    Samples ``num_samples`` vertices with replacement; the matched
    fraction times ``n/2`` estimates |MM| with additive error
    ``O(n / sqrt(num_samples))`` whp (Chernoff).  This is the textbook
    randomized estimator the pipelines rely on; experiment E5 shows why
    its *derandomised* counterpart (fixed sample/probe set) fails.
    """
    n = oracle.graph.n
    matched = sum(
        1 for _ in range(num_samples) if oracle.vertex_matched(rng.randrange(n))
    )
    return (matched / num_samples) * n / 2.0


def fixed_probe_edge_detector(
    n: int,
    probes: list[tuple[int, int]],
    edge_set: set[tuple[int, int]],
) -> int:
    """The *derandomised* detector of experiment E5.

    Probes a fixed pair list (the published "seed"); returns the number
    of probes that hit an edge.  Deciding "mu = 0 vs mu >= n/4" from a
    fixed probe set is exactly what Lemma 3.6 of the plan rules out with
    o(n^2) probes; E5 realises the adversary constructively.
    """
    return sum(1 for p in probes if p in edge_set)
