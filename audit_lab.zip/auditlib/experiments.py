"""Experiments E1--E5: empirical evidence for the audit-table rows.

Every experiment returns a plain ``dict`` (JSON-serialisable) and is
deterministic given its ``seed``.  Sizes are controlled by a single
``scale`` knob ("quick" for CI, "full" for the report run).

Mapping to the audit table (``audit_table.py``):
  E1 -> R1 (what sampling buys: whp accuracy at sublinear locality)
  E2 -> R2 (failure if ranks fixed: Theta(m) per-query locality)
  E3 -> R2/R1 (limited independence: k-wise sweep)
  E4 -> R2 (failure if ranks fixed, dynamic: Theta(n) recourse)
  E5 -> R1/R4 (failure if samples fixed: planted mass off the probes;
        constructive companion of plan Lemma 3.6 / Cor. 3.7)
"""

from __future__ import annotations

import random
import statistics
from typing import Any

from .graphs import Graph, complement_pairs, gnp_graph, path_graph
from .matching import (
    greedy_maximal_matching,
    is_maximal_matching,
    maximum_matching,
)
from .ranks import FixedRanks, FullyRandomRanks, KWiseRanks, RankSource
from .rgmm import (
    GreedyMatchingOracle,
    estimate_mm_size_by_vertex_sampling,
    fixed_probe_edge_detector,
)


def _mean_std(xs: list[float]) -> tuple[float, float]:
    if len(xs) == 1:
        return xs[0], 0.0
    return statistics.fmean(xs), statistics.stdev(xs)


# ======================================================================
# E1 -- what the randomness buys: concentration + sublinear locality
# ======================================================================

def e1_estimator_concentration(seed: int, scale: str) -> dict[str, Any]:
    """Vertex-sampling estimator vs ground truth on G(n, d/n).

    Checks, per trial: (a) |estimate - |MM|| / n shrinks like
    1/sqrt(samples); (b) |MM| in [mu/2, mu] (Blossom cross-check, run at
    a size where O(n^3) Python is fine); (c) locality: evaluations per
    sampled vertex stays O(1)-ish, far below m.
    """
    n = 1500 if scale == "quick" else 4000
    n_exact = 240  # Blossom cross-check size
    avg_degree = 5.0
    sample_grid = [100, 400, 1600] if scale == "quick" else [100, 400, 1600, 6400]
    trials = 6 if scale == "quick" else 15
    rng = random.Random(seed)

    per_samples: dict[int, dict[str, Any]] = {}
    for s in sample_grid:
        errs: list[float] = []
        evals_per_query: list[float] = []
        for _ in range(trials):
            g = gnp_graph(n, avg_degree, rng)
            ranks = FullyRandomRanks(random.Random(rng.getrandbits(64)))
            truth = len(greedy_maximal_matching(g, ranks.key))
            oracle = GreedyMatchingOracle(g, ranks.key)
            est = estimate_mm_size_by_vertex_sampling(
                oracle, s, random.Random(rng.getrandbits(64))
            )
            errs.append(abs(est - truth) / n)
            evals_per_query.append(oracle.evaluations / s)
        m_err, s_err = _mean_std(errs)
        m_ev, _ = _mean_std(evals_per_query)
        per_samples[s] = {
            "mean_abs_err_over_n": m_err,
            "std_abs_err_over_n": s_err,
            "mean_evaluations_per_vertex_query": m_ev,
        }

    # (b) half-approximation cross-check at exact-solver size
    half_ok, ratios = True, []
    for _ in range(trials):
        g = gnp_graph(n_exact, avg_degree, rng)
        ranks = FullyRandomRanks(random.Random(rng.getrandbits(64)))
        mm = greedy_maximal_matching(g, ranks.key)
        assert is_maximal_matching(g, mm)
        mu, _ = maximum_matching(g)
        if mu:
            ratios.append(len(mm) / mu)
            half_ok &= mu / 2 <= len(mm) <= mu
    return {
        "experiment": "e1",
        "params": {"n": n, "avg_degree": avg_degree, "trials": trials},
        "by_num_samples": per_samples,
        "half_approx_always_held": half_ok,
        "mm_over_mu_min": min(ratios),
        "mm_over_mu_mean": statistics.fmean(ratios),
    }


# ======================================================================
# E2 -- failure if ranks fixed: Theta(m) locality on adversarial paths
# ======================================================================

def e2_fixed_rank_locality_blowup(seed: int, scale: str) -> dict[str, Any]:
    """Rank-decreasing path: one oracle query costs exactly m evaluations.

    Adversarial fixed ranks r(e_i) = m - i make every edge depend on its
    successor; querying edge 0 resolves the whole chain.  Fully random
    ranks on the same path keep the cost O(1) on average -- the cleanest
    picture of what audit row R2's randomness buys.
    """
    sizes = [1000, 4000] if scale == "quick" else [1000, 4000, 16000, 64000]
    rng = random.Random(seed)
    rows = []
    for m in sizes:
        g = path_graph(m)
        adversarial = FixedRanks({e: m - e for e in range(m)})
        oracle_fixed = GreedyMatchingOracle(g, adversarial.key)
        oracle_fixed.edge_in_matching(0)  # head query
        fixed_cost = oracle_fixed.evaluations

        rand_costs = []
        for _ in range(30):
            ranks = FullyRandomRanks(random.Random(rng.getrandbits(64)))
            oracle = GreedyMatchingOracle(g, ranks.key)
            oracle.edge_in_matching(rng.randrange(m))
            rand_costs.append(oracle.evaluations)
        rows.append({
            "m": m,
            "fixed_rank_head_query_evaluations": fixed_cost,
            "fixed_equals_m": fixed_cost == m,
            "random_rank_mean_evaluations": statistics.fmean(rand_costs),
            "random_rank_max_evaluations": max(rand_costs),
        })
    return {"experiment": "e2", "rows": rows}


# ======================================================================
# E3 -- limited independence: k-wise sweep (Task A4 input)
# ======================================================================

def e3_limited_independence(seed: int, scale: str) -> dict[str, Any]:
    """Replace fully random ranks by k-wise independent ranks.

    Two measurements per source: (a) estimator accuracy + locality on
    G(n, d/n) as in E1; (b) locality on the E2 path with *oblivious*
    (not rank-aware) adversary, i.e. does small k already avoid long
    rank-decreasing runs?  Empirical only; no theory is claimed.
    """
    n = 1200 if scale == "quick" else 3000
    avg_degree = 5.0
    samples = 800
    trials = 6 if scale == "quick" else 15
    path_m = 4000 if scale == "quick" else 20000
    ks = [2, 3, 4, 8]
    rng = random.Random(seed)

    def make_sources() -> list[tuple[str, RankSource]]:
        out: list[tuple[str, RankSource]] = [
            (f"{k}-wise", KWiseRanks(k=k, rng=random.Random(rng.getrandbits(64))))
            for k in ks
        ]
        out.append(("full", FullyRandomRanks(random.Random(rng.getrandbits(64)))))
        return out

    accuracy: dict[str, dict[str, float]] = {}
    for _ in range(trials):
        g = gnp_graph(n, avg_degree, rng)
        for name, src in make_sources():
            truth = len(greedy_maximal_matching(g, src.key))
            oracle = GreedyMatchingOracle(g, src.key)
            est = estimate_mm_size_by_vertex_sampling(
                oracle, samples, random.Random(rng.getrandbits(64))
            )
            acc = accuracy.setdefault(name, {"errs": [], "evals": []})  # type: ignore[arg-type]
            acc["errs"].append(abs(est - truth) / n)          # type: ignore[union-attr]
            acc["evals"].append(oracle.evaluations / samples)  # type: ignore[union-attr]

    g_path = path_graph(path_m)
    path_locality: dict[str, float] = {}
    for name, src in make_sources():
        oracle = GreedyMatchingOracle(g_path, src.key)
        costs = []
        for _ in range(40):
            before = oracle.evaluations
            oracle.edge_in_matching(rng.randrange(path_m))
            costs.append(oracle.evaluations - before)
        path_locality[name] = statistics.fmean(costs)

    summary = {
        name: {
            "mean_abs_err_over_n": statistics.fmean(d["errs"]),
            "mean_evaluations_per_vertex_query": statistics.fmean(d["evals"]),
            "path_mean_marginal_evaluations": path_locality[name],
        }
        for name, d in accuracy.items()
    }
    return {
        "experiment": "e3",
        "params": {"n": n, "samples": samples, "trials": trials,
                   "path_m": path_m, "ks": ks},
        "by_source": summary,
    }


# ======================================================================
# E4 -- failure if ranks fixed, dynamic: Theta(n) recourse per update
# ======================================================================

def e4_fixed_rank_recourse(seed: int, scale: str) -> dict[str, Any]:
    """Head-edge toggling on a path: fixed increasing ranks flip the whole
    greedy matching every update (recourse ~ n); random ranks, against the
    same oblivious update sequence, keep mean recourse O(1)-ish.

    Empirical companion of plan Task A3(b) (fixed-rank greedy recourse
    lower bound, status [S]).
    """
    L = 1000 if scale == "quick" else 4000  # path has 2L edges
    toggles = 30
    rand_runs = 5
    rng = random.Random(seed)
    m = 2 * L
    g = path_graph(m)

    def recourse_trace(rank_key) -> list[int]:
        active = set(range(m))
        current = greedy_maximal_matching(g, rank_key, active)
        trace = []
        for t in range(toggles):
            if t % 2 == 0:
                active.discard(0)
            else:
                active.add(0)
            new = greedy_maximal_matching(g, rank_key, active)
            trace.append(len(current ^ new))
            current = new
        return trace

    fixed_trace = recourse_trace(FixedRanks({e: e for e in range(m)}).key)
    rand_means = []
    for _ in range(rand_runs):
        src = FullyRandomRanks(random.Random(rng.getrandbits(64)))
        rand_means.append(statistics.fmean(recourse_trace(src.key)))
    return {
        "experiment": "e4",
        "params": {"path_edges": m, "toggles": toggles},
        "fixed_rank_mean_recourse_per_update": statistics.fmean(fixed_trace),
        "fixed_rank_min_recourse_per_update": min(fixed_trace),
        "random_rank_mean_recourse_per_update": statistics.fmean(rand_means),
        "ratio_fixed_over_random": (
            statistics.fmean(fixed_trace) / max(statistics.fmean(rand_means), 1e-9)
        ),
    }


# ======================================================================
# E5 -- failure if samples fixed: plant off the probe set (Lemma 3.6)
# ======================================================================

def e5_fixed_probe_plant(seed: int, scale: str) -> dict[str, Any]:
    """Constructive adversary against a fixed ("derandomised") probe set.

    Detector D probes a fixed pseudorandom pair set P (|P| = B, seed
    published).  The adversary, knowing P, builds G as a maximum matching
    of the complement K_n - P.  Outcomes per budget B:

    * plant size found by Blossom on K_n - P (>= n/4 is guaranteed by the
      plan's Lemma 3.6 argument while B <= C(ceil(n/2), 2) - 1);
    * D's hit count (0 by construction): D answers "mu = 0", truth >= n/4;
    * empirical detection probability of the *randomized* detector with
      the same budget of fresh uniform probes.
    """
    n = 64 if scale == "quick" else 96
    total_pairs = n * (n - 1) // 2
    lemma_threshold = (n // 2 + n % 2) * ((n // 2 + n % 2) - 1) // 2  # C(ceil(n/2),2)
    budgets = sorted({
        n // 2, 2 * n, 8 * n, lemma_threshold - 1, lemma_threshold,
        int(0.6 * total_pairs), int(0.9 * total_pairs),
    })
    rand_trials = 300
    rng = random.Random(seed)

    all_pairs = complement_pairs(n, set())
    fixed_perm = all_pairs[:]
    random.Random(0).shuffle(fixed_perm)  # the published "seed-0" probe order

    rows = []
    for budget in budgets:
        probe_set = set(fixed_perm[:budget])
        free = complement_pairs(n, probe_set)
        comp_graph = Graph(n, free)
        plant_size, match = maximum_matching(comp_graph)
        plant_edges = {
            tuple(sorted((v, match[v]))) for v in range(n) if match[v] != -1
        }
        # Truncate the plant to exactly ceil(n/4) edges when possible, to
        # present the cleanest "mu = 0 vs mu >= n/4" gap instance.
        target = -(-n // 4)
        plant = set(sorted(plant_edges)[:target]) if plant_size >= target else plant_edges
        det_hits = fixed_probe_edge_detector(n, fixed_perm[:budget], plant)

        detections = 0
        if plant:
            for _ in range(rand_trials):
                trial_rng = random.Random(rng.getrandbits(64))
                if any(
                    tuple(sorted(trial_rng.sample(range(n), 2))) in plant
                    for _ in range(budget)
                ):
                    detections += 1
        rows.append({
            "budget_B": budget,
            "complement_max_matching": plant_size,
            "plant_size_used": len(plant),
            "plant_at_least_n_over_4": plant_size >= target,
            "deterministic_detector_hits": det_hits,
            "randomized_detection_prob": detections / rand_trials if plant else None,
        })
    return {
        "experiment": "e5",
        "params": {
            "n": n,
            "total_pairs": total_pairs,
            "lemma_threshold_C_ceil_n2_2": lemma_threshold,
            "rand_trials": rand_trials,
        },
        "rows": rows,
    }


ALL_EXPERIMENTS = {
    "e1": e1_estimator_concentration,
    "e2": e2_fixed_rank_locality_blowup,
    "e3": e3_limited_independence,
    "e4": e4_fixed_rank_recourse,
    "e5": e5_fixed_probe_plant,
}
