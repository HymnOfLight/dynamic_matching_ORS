"""Graph data structures and instance generators for the A0 randomness audit.

Design notes
------------
* Edges are referred to by integer ids (0..m-1).  All rank sources
  (see ``ranks.py``) map edge ids to sortable keys, so a graph plus a
  rank source fully determines the greedy maximal matching.
* The class is deliberately immutable after construction; "dynamic"
  experiments (E4) model updates as an *active-edge mask* on top of a
  fixed instance, which keeps the code simple and the measurements
  unambiguous.
"""

from __future__ import annotations

import itertools
import random
from dataclasses import dataclass, field
from typing import Iterator


@dataclass
class Graph:
    """A simple undirected graph with integer-id edges.

    Attributes
    ----------
    n:
        Number of vertices, labelled ``0..n-1``.
    edges:
        ``edges[e] = (u, v)`` with ``u < v``; the index ``e`` is the edge id.
    """

    n: int
    edges: list[tuple[int, int]]
    _incident: list[list[int]] = field(init=False, repr=False)

    def __post_init__(self) -> None:
        seen: set[tuple[int, int]] = set()
        incident: list[list[int]] = [[] for _ in range(self.n)]
        for e, (u, v) in enumerate(self.edges):
            if not (0 <= u < self.n and 0 <= v < self.n):
                raise ValueError(f"edge {e}=({u},{v}) out of range")
            if u == v:
                raise ValueError(f"edge {e} is a self-loop")
            if u > v:
                raise ValueError(f"edge {e}=({u},{v}) must satisfy u < v")
            if (u, v) in seen:
                raise ValueError(f"duplicate edge ({u},{v})")
            seen.add((u, v))
            incident[u].append(e)
            incident[v].append(e)
        self._incident = incident

    # ------------------------------------------------------------------
    @property
    def m(self) -> int:
        return len(self.edges)

    def incident_edges(self, v: int) -> list[int]:
        """Edge ids incident to vertex ``v``."""
        return self._incident[v]

    def adjacent_edges(self, e: int) -> Iterator[int]:
        """Edge ids sharing an endpoint with ``e`` (excluding ``e``)."""
        u, v = self.edges[e]
        for f in self._incident[u]:
            if f != e:
                yield f
        for f in self._incident[v]:
            if f != e:
                yield f

    def adjacency_lists(self) -> list[list[int]]:
        """Vertex adjacency lists (for the exact-matching solvers)."""
        adj: list[list[int]] = [[] for _ in range(self.n)]
        for u, v in self.edges:
            adj[u].append(v)
            adj[v].append(u)
        return adj


# ======================================================================
# Instance generators
# ======================================================================

def gnp_graph(n: int, avg_degree: float, rng: random.Random) -> Graph:
    """Erdos--Renyi ``G(n, p)`` with ``p = avg_degree / (n - 1)``.

    Sampled via a geometric skip over the pair enumeration, so the cost
    is ``O(n + m)`` rather than ``O(n^2)`` -- important for E1/E3 sizes.
    """
    if n < 2:
        return Graph(n, [])
    p = min(1.0, avg_degree / (n - 1))
    edges: list[tuple[int, int]] = []
    if p <= 0.0:
        return Graph(n, edges)
    # Enumerate pairs (u, v), u < v, in row-major order with geometric skips.
    import math

    log_q = math.log1p(-p) if p < 1.0 else None
    idx = -1
    total = n * (n - 1) // 2
    while True:
        if log_q is None:
            idx += 1
        else:
            r = rng.random()
            idx += 1 + int(math.log(1.0 - r) / log_q) if r > 0 else 1
        if idx >= total:
            break
        u, v = _pair_from_index(idx, n)
        edges.append((u, v))
    return Graph(n, edges)


def _pair_from_index(idx: int, n: int) -> tuple[int, int]:
    """Inverse of the row-major enumeration of pairs ``(u, v), u < v``.

    Row ``u`` (pairs ``(u, u+1) .. (u, n-1)``) starts at offset
    ``_row_offset(u, n)``; binary-search the largest ``u`` whose offset
    is ``<= idx``.  Pure integer arithmetic -- no float edge cases.
    """
    lo, hi = 0, n - 2  # valid rows are 0 .. n-2
    while lo < hi:
        mid = (lo + hi + 1) // 2
        if _row_offset(mid, n) <= idx:
            lo = mid
        else:
            hi = mid - 1
    u = lo
    v = u + 1 + (idx - _row_offset(u, n))
    return u, v


def _row_offset(u: int, n: int) -> int:
    """Index of pair ``(u, u+1)``: sum_{i<u} (n-1-i) = u(n-1) - u(u-1)/2."""
    return u * (n - 1) - u * (u - 1) // 2


def path_graph(num_edges: int) -> Graph:
    """Path ``0 - 1 - ... - num_edges`` with edge id ``i`` = (i, i+1)."""
    return Graph(num_edges + 1, [(i, i + 1) for i in range(num_edges)])


def complement_pairs(n: int, forbidden: set[tuple[int, int]]) -> list[tuple[int, int]]:
    """All pairs ``(u, v), u < v`` not in ``forbidden`` (E5 helper, small n)."""
    return [
        (u, v)
        for u, v in itertools.combinations(range(n), 2)
        if (u, v) not in forbidden
    ]
