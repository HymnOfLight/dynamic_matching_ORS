"""Rank sources: the randomness objects the audit is about.

The greedy maximal matching is parameterised by a total order ("ranks")
on edges.  The three sources below correspond to the three columns of the
audit table:

* ``FullyRandomRanks``      -- what the analysed papers assume;
* ``KWiseRanks``            -- limited independence (audit column iii);
* ``FixedRanks``            -- a fixed/derandomised order known to the
                               adversary (audit column ii, "failure mode
                               if fixed").

All sources expose ``key(edge_id) -> tuple`` returning a *distinct*
sortable key (ties broken by edge id), so any source defines a valid
strict total order.
"""

from __future__ import annotations

import random
from dataclasses import dataclass, field

_MERSENNE_PRIME = (1 << 61) - 1  # 2^61 - 1, comfortably above any m used


class RankSource:
    """Interface: a strict total order on edge ids."""

    def key(self, edge_id: int) -> tuple:
        raise NotImplementedError

    def describe(self) -> str:
        raise NotImplementedError


@dataclass
class FullyRandomRanks(RankSource):
    """A uniformly random permutation of the ``m`` edges.

    Implemented lazily: each edge id receives an independent 64-bit value
    on first access (ties broken by id), which induces a uniform random
    order without materialising a permutation up front.
    """

    rng: random.Random
    _values: dict[int, int] = field(default_factory=dict)

    def key(self, edge_id: int) -> tuple:
        v = self._values.get(edge_id)
        if v is None:
            v = self.rng.getrandbits(64)
            self._values[edge_id] = v
        return (v, edge_id)

    def describe(self) -> str:
        return "fully-random"


@dataclass
class KWiseRanks(RankSource):
    """A ``k``-wise independent rank family.

    ``value(x) = (a_0 + a_1 x + ... + a_{k-1} x^{k-1}) mod p`` with random
    coefficients over the Mersenne prime ``p = 2^61 - 1``.  Evaluations at
    any ``k`` distinct points are independent and uniform mod ``p`` (the
    classical polynomial construction); ties are broken by edge id.

    This is the object Task A4 asks about: do the locality analyses of
    the RGMM oracle survive when full independence is replaced by small
    ``k``?  Experiment E3 probes the question empirically.
    """

    k: int
    rng: random.Random
    prime: int = _MERSENNE_PRIME
    _coeffs: list[int] = field(init=False)

    def __post_init__(self) -> None:
        if self.k < 1:
            raise ValueError("k must be >= 1")
        self._coeffs = [self.rng.randrange(self.prime) for _ in range(self.k)]

    def key(self, edge_id: int) -> tuple:
        # Horner evaluation of the degree-(k-1) polynomial at x = edge_id+1
        # (shift avoids the always-fixed value at x = 0 when k = 1).
        x = (edge_id + 1) % self.prime
        acc = 0
        for c in reversed(self._coeffs):
            acc = (acc * x + c) % self.prime
        return (acc, edge_id)

    def describe(self) -> str:
        return f"{self.k}-wise"


@dataclass
class FixedRanks(RankSource):
    """An explicit, fixed total order (the derandomised / adversarial case).

    ``order[edge_id] = position``; lower position = earlier in greedy.
    Used by the adversarial constructions in experiments E2 and E4, and
    to model "PRG with a published seed" (a fixed order the worst-case
    adversary may inspect -- see the Remark after Corollary 3.7 of the
    plan: fixing a seed does not escape the deterministic lower bound).
    """

    order: dict[int, int]

    def key(self, edge_id: int) -> tuple:
        return (self.order[edge_id], edge_id)

    def describe(self) -> str:
        return "fixed (adversary-known)"


def make_rank_source(kind: str, rng: random.Random, k: int = 0) -> RankSource:
    """Factory used by the experiment CLI (`kind` in {full, kwise})."""
    if kind == "full":
        return FullyRandomRanks(rng)
    if kind == "kwise":
        return KWiseRanks(k=k, rng=rng)
    raise ValueError(f"unknown rank source kind: {kind!r}")
