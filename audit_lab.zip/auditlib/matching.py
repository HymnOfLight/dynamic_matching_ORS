"""Matching algorithms: exact maximum matching (two independent solvers,
cross-validated) and rank-driven greedy maximal matching.

Cross-validation methodology
----------------------------
Following the project's standing rule, every quantity that enters a result
is computed by two independent implementations:

* ``maximum_matching_size_bruteforce``  -- bitmask DP, exact for n <= ~20;
* ``maximum_matching``                  -- Blossom algorithm (O(n^3)),
  exact for all n, validated against the DP in ``tests.py``.

The greedy maximal matching defined by an edge ranking is the object the
RGMM oracle (``rgmm.py``) computes locally; ``greedy_maximal_matching``
is its independent *global* implementation, used as ground truth.
"""

from __future__ import annotations

from collections import deque
from typing import Callable

from .graphs import Graph

RankKey = Callable[[int], object]  # edge id -> sortable key


# ======================================================================
# Solver 1: bitmask dynamic programming (exact, n <= ~20)
# ======================================================================

def maximum_matching_size_bruteforce(graph: Graph) -> int:
    """Exact maximum matching size via DP over vertex subsets.

    ``f(S)`` = maximum matching size inside vertex set ``S``; the lowest
    vertex of ``S`` is either unmatched or matched to a neighbour in ``S``.
    Complexity ``O(2^n * n)``; intended for n <= 20 (test oracle only).
    """
    n = graph.n
    if n > 22:
        raise ValueError("bruteforce solver is restricted to n <= 22")
    adj_mask = [0] * n
    for u, v in graph.edges:
        adj_mask[u] |= 1 << v
        adj_mask[v] |= 1 << u

    memo: dict[int, int] = {0: 0}

    def f(s: int) -> int:
        if s in memo:
            return memo[s]
        v = (s & -s).bit_length() - 1
        rest = s & ~(1 << v)
        best = f(rest)  # leave v unmatched
        nb = adj_mask[v] & rest
        while nb:
            u_bit = nb & -nb
            nb ^= u_bit
            best = max(best, 1 + f(rest & ~u_bit))
        memo[s] = best
        return best

    return f((1 << n) - 1)


# ======================================================================
# Solver 2: Blossom algorithm (exact, general graphs, O(n^3))
# ======================================================================

def maximum_matching(graph: Graph) -> tuple[int, list[int]]:
    """Maximum matching in a general graph (classic Blossom contraction).

    Returns ``(size, match)`` where ``match[v]`` is the partner of ``v``
    or ``-1``.  Standard textbook implementation (Edmonds' blossoms via
    base-contraction BFS); correctness is established empirically against
    the bitmask DP in ``tests.py`` (this pairing is the point).
    """
    n = graph.n
    adj = graph.adjacency_lists()
    match = [-1] * n
    p = [-1] * n          # BFS parent across unmatched edges
    base = list(range(n))  # blossom base of each vertex

    def lca(a: int, b: int) -> int:
        used_path = [False] * n
        x = a
        while True:
            x = base[x]
            used_path[x] = True
            if match[x] == -1:
                break
            x = p[match[x]]
        y = b
        while True:
            y = base[y]
            if used_path[y]:
                return y
            y = p[match[y]]

    def mark_path(v: int, b: int, child: int, blossom: list[bool]) -> None:
        while base[v] != b:
            blossom[base[v]] = True
            blossom[base[match[v]]] = True
            p[v] = child
            child = match[v]
            v = p[match[v]]

    def find_augmenting_path(root: int) -> bool:
        nonlocal p, base
        used = [False] * n
        p = [-1] * n
        base = list(range(n))
        used[root] = True
        queue: deque[int] = deque([root])
        while queue:
            v = queue.popleft()
            for to in adj[v]:
                if base[v] == base[to] or match[v] == to:
                    continue
                if to == root or (match[to] != -1 and p[match[to]] != -1):
                    # odd cycle detected -> contract blossom
                    cur_base = lca(v, to)
                    blossom = [False] * n
                    mark_path(v, cur_base, to, blossom)
                    mark_path(to, cur_base, v, blossom)
                    for i in range(n):
                        if blossom[base[i]]:
                            base[i] = cur_base
                            if not used[i]:
                                used[i] = True
                                queue.append(i)
                elif p[to] == -1:
                    p[to] = v
                    if match[to] == -1:
                        # augment along the alternating path ending at `to`
                        u = to
                        while u != -1:
                            pv = p[u]
                            ppv = match[pv]
                            match[u] = pv
                            match[pv] = u
                            u = ppv
                        return True
                    used[match[to]] = True
                    queue.append(match[to])
        return False

    size = 0
    for v in range(n):
        if match[v] == -1 and find_augmenting_path(v):
            size += 1
    return size, match


# ======================================================================
# Rank-driven greedy maximal matching (global ground truth for the oracle)
# ======================================================================

def greedy_maximal_matching(
    graph: Graph,
    rank_key: RankKey,
    active: set[int] | None = None,
) -> set[int]:
    """Edge ids of the greedy maximal matching along increasing rank.

    Parameters
    ----------
    rank_key:
        Total order on edge ids (strict: keys must be distinct).
    active:
        If given, restrict to this edge-id subset (used by the dynamic
        recourse experiment E4).
    """
    edge_ids = range(graph.m) if active is None else sorted(active)
    order = sorted(edge_ids, key=rank_key)
    used_vertex = [False] * graph.n
    chosen: set[int] = set()
    for e in order:
        u, v = graph.edges[e]
        if not used_vertex[u] and not used_vertex[v]:
            used_vertex[u] = used_vertex[v] = True
            chosen.add(e)
    return chosen


def is_maximal_matching(graph: Graph, chosen: set[int]) -> bool:
    """Independent validity check: ``chosen`` is a matching and maximal."""
    used = [False] * graph.n
    for e in chosen:
        u, v = graph.edges[e]
        if used[u] or used[v]:
            return False
        used[u] = used[v] = True
    for u, v in graph.edges:
        if not used[u] and not used[v]:
            return False
    return True
