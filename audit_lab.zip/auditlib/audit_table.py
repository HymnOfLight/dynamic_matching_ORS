"""Machine-readable randomness-audit table (Task A0, plan §4 / WS-D) -- v0.2.

Each :class:`AuditRow` maps one random choice inside the analysed
pipelines [BKSW23, Beh23, ABR24, BG24, AKK25] to the three audit
questions of Task A0: (i) what the randomness buys, (ii) the failure
mode if it is fixed, (iii) whether limited independence plausibly
suffices -- plus evidence (experiments E1..E5, plan statements) and a
status tag.

v0.3 (read-through pass 2, June 2026): rows upgraded with lemma-level
locations verified directly against arXiv full texts:
  BG24  = arXiv:2404.06069v4 (read: SS1-4.4),
  AKK25 = arXiv:2406.13573  (read: SS1-4.1),
  Beh21 = arXiv:2106.02942v3 (read: SS1-3, SS5 statements),
  BKSW23= arXiv:2207.07438v3 (abstract + App. A Prop. A.1 + JACM SS2/SS5),
  Beh23 = arXiv:2207.07607v2 (abstract + SS1 technique overview),
  ABR24 = arXiv:2307.08772v1 (read: SS1-4; Thm 1 adversary verified).
Numbering caveat: AKK25 cites BG24's Lemmas 9/14 (earlier version);
in v4 these are Lemma 7 and Lemma 11 respectively -- we cite v4.
NOT yet re-read: BDHSS19/Sol16 maintenance internals, BKSW23 SS5+
robustness lemmas, Kis22 full internals (its Prop. A.1 form is verified
via BKSW23); rows touching these keep an [M] residue.

Status tags as in the plan: [V] verified against source, [M] precise
internal reference pending, [P] proved in plan, [S] sketch,
[E:*] empirical evidence in this package.
"""

from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class AuditRow:
    row_id: str
    papers: str                      # where the mechanism appears
    mechanism: str                   # the random choice, concretely
    buys: str                        # (i)  property purchased
    failure_if_fixed: str            # (ii) what breaks when fixed
    limited_independence: str        # (iii) k-wise status
    evidence: str                    # experiments / plan statements
    status: str                      # tag string, e.g. "[V][E:e2]"


AUDIT_ROWS: list[AuditRow] = [
    AuditRow(
        row_id="R1",
        papers="all five (engine: Beh21)",
        mechanism=(
            "Sublinear Monte-Carlo matching-size estimation via "
            "adjacency-matrix queries (Beh21). Verified statements: "
            "BG24 Prop. 4; AKK25 Prop. 2.3 (Otilde(n poly(1/eps)) "
            "queries, whp 0.5mu - eps n <= est <= mu); BKSW23 abstract "
            "('invoke ... Behnezhad (FOCS'21) in a white-box manner' "
            "for the second streaming pass); Beh23 SS1 ('key tool ... "
            "estimating the size of maximal matchings in Otilde(n) "
            "time'); ABR24 SS1 (phase 2 'augment ... by employing the "
            "sublinear-time matching size estimator of [Beh21]')."
        ),
        buys=(
            "Per-rebuild Otilde(n) cost with whp additive accuracy; the "
            "only access to the (kernel/contracted/leftover) graph is "
            "via probes."
        ),
        failure_if_fixed=(
            "Adversary who knows the fixed probe/sample set plants all "
            "matching mass outside it: estimator reports ~0 while mu >= "
            "n/4. Provably no deterministic probe algorithm with o(n^2) "
            "probes exists (plan Lemma 3.6); no drop-in derandomisation "
            "of this interface (plan Cor. 3.7)."
        ),
        limited_independence=(
            "Chebyshev-level accuracy needs only pairwise sample "
            "choices; whp needs k = Theta(log n)-wise tails. Whether "
            "the surrounding union bounds tolerate the weaker tails is "
            "Task A4. Beh21-internal requirements not yet re-read."
        ),
        evidence="E1 (works); E5 (fixed fails); Lemma 3.6; Cor 3.7",
        status="[V][P][E:e1,e5]",
    ),
    AuditRow(
        row_id="R2",
        papers="Beh21 inside all five; phase-1 of Beh23/ABR24",
        mechanism=(
            "Uniformly random edge/vertex ranks driving greedy maximal "
            "matching: (a) inside the Beh21 estimator (local RGMM "
            "oracle); (b) as the explicitly maintained phase-1 maximal "
            "matching of the size pipelines -- ABR24 SS1: 'maintain a "
            "maximal matching explicitly using the fast algorithms of "
            "[BGS, Sol16, BDHSS19]' (randomized, oblivious-adversary "
            "maintenance)."
        ),
        buys=(
            "Verified (Beh21 Thm 3.5): E[T(v,pi)] = O(dbar log n) over "
            "uniformly random v AND uniformly random pi, via the "
            "directional oracles VO/EO (Beh21 Algs 1-2, Remark 3.3); "
            "caching gives poly(n) worst case with prob. 1 (Remark 3.2, "
            "Obs 3.7). In ABR24 the random order is ADDITIONALLY load-"
            "bearing for the approximation analysis of the b-matching "
            "(even-spread-of-copies argument, ABR24 SS2), not only for "
            "locality."
        ),
        failure_if_fixed=(
            "Rank-aware adversary builds a rank-decreasing path: one "
            "oracle query costs Theta(m) (E2); head-edge toggling "
            "forces Theta(n) recourse per update (E4). Approximation "
            "is NOT what breaks (any maximal matching stays 1/2)."
        ),
        limited_independence=(
            "VERIFIED OBSTRUCTION (Beh21 SS3): the charging proof of "
            "Lemma 3.10 maps a permutation pi to phi(pi, P) by rotating "
            "ranks along query paths -- a bijection of the FULL "
            "symmetric group. k-wise families are not closed under "
            "these rotations, so the O(dbar log n) locality analysis "
            "does not transfer to limited independence as-is (Task A4 "
            "now has a precise technical obstacle). Empirically (E3): "
            "even k=2 matches full independence on oblivious instances "
            "-- a genuine analysis/experiment gap. BDHSS19 maintenance "
            "internals unread [M]."
        ),
        evidence="E2 (Theta(m) blowup); E4 (Theta(n) recourse); E3 (k-wise)",
        status="[V][M][E:e2,e3,e4]",
    ),
    AuditRow(
        row_id="R3",
        papers="BKSW23; Beh23; ABR24; BG24; AKK25",
        mechanism=(
            "Adaptive-adversary robustness wrappers. Verified claims: "
            "BKSW23 abstract (adaptive + worst-case polylog, both whp); "
            "BG24 SS3 (adversary sees previous outputs) + Thm 1; AKK25 "
            "Result 1 + Problem 1 (adaptively chosen queries); Beh23 SS1 "
            "(vertex sparsification 'can be made work against adaptive "
            "adversaries too [Kis22]'); ABR24 Thm 1 ('poly(log n) "
            "worst-case update time even against adaptive adversaries', "
            "via LOCAL-model simulation on the bounded-degree G[M u B] "
            "+ size-only output); BKSW23 worst-case via "
            "deamortization (JACM SS2: 'easily deamortized'). "
            "Mechanism: low-sensitivity "
            "outputs (sizes; or an explicit matching only shrunk by "
            "deletions between rebuilds, BG24 Lemma 9) + fresh coins "
            "per rebuild/call + whp union bounds over poly(n) updates."
        ),
        buys="Correctness whp against adversaries that see the outputs.",
        failure_if_fixed=(
            "With fixed coins the transcript determines internal "
            "randomness; every adversary is effectively adaptive "
            "against a deterministic algorithm -- OP-D has no "
            "'oblivious deterministic' easy mode (plan SS2.1, Obs 3.4)."
        ),
        limited_independence=(
            "Across rebuilds: coins must be fresh/independent. Within "
            "a rebuild: inherits from R1/R2/R4/R5."
        ),
        evidence="conceptual; plan SS2.1, Obs. 3.4; BG24 Alg 2 ll.17-20",
        status="[V][M]",
    ),
    AuditRow(
        row_id="R4",
        papers="BG24",
        mechanism=(
            "RandomSampling (BG24 Algorithm 1, Lemma 7): per-vertex "
            "uniform sampling of candidate partners with geometrically "
            "doubling budgets b = n^{2 delta (i-1)}; whp degree bound "
            "via Claim 8 (per-(v,i) failure 1/n^3, union bound). Fresh "
            "coins per call; called from MatchAndCertify (Lemma 6) "
            "inside Algorithm 2 every eps n/2 updates."
        ),
        buys=(
            "Finds an Omega_eps(n) matching in G[U] in Otilde(n^{2+eps}"
            "/d) where d = avg internal degree of the certificate -- "
            "fast exactly when the instance is far from induced."
        ),
        failure_if_fixed=(
            "Adversary aligns the instance with the fixed sample "
            "schedule: plant-off-the-samples (E5 mechanism) breaks the "
            "Claim-8 degree invariant. NOTE (verified): the ORS "
            "charging itself (Lemma 11), H_cert bookkeeping, and the "
            "boosting wrapper (Prop. 3) are deterministic -- the coins "
            "of BG24 live ONLY in Lemma 7 + the R1/R7 interfaces."
        ),
        limited_independence=(
            "Claim 8 needs (1-p)^{Omega(log n / p)} <= n^{-Theta(1)} "
            "tails: Theta(log n)-wise independence plausibly suffices "
            "(Bonferroni truncation) -- unproven, input to Task A4 [S]."
        ),
        evidence="E5 (mechanism); BG24 Lem 7, Claim 8, Lem 11, Alg 2",
        status="[V][E:e5]",
    ),
    AuditRow(
        row_id="R5",
        papers="AKK25",
        mechanism=(
            "Opportunistic sublinear matcher (AKK25 Algorithm 1, Lemma "
            "3.1): per-vertex neighbour sampling with geometric "
            "probabilities p_i = n^{3 gamma i}/n (binomial-count "
            "implementation, fn.1); whp runtime via Claim 3.3 "
            "(Chernoff) and max-internal-degree via Claim 3.4 "
            "('residual sparsity' + union bound). Used inside the "
            "three-graph batch scheme (G_old/G_batch/G_match, Alg 2, "
            "Lemma 4.1) and recursed via the family {A_i} (SS4.2)."
        ),
        buys=(
            "Strengthens BG24 Lemma 7: Otilde(m n^{3 gamma}/"
            "Delta_IN(M)) time, sensitive to |E| and to MAX (not avg) "
            "internal degree -- this is what removes the sqrt(n) "
            "factor. Worst-case Omega(m) is necessary: ACK19 (Assadi-Chen-"
            "Khanna SODA'19) Thm 6 -- FINDING a maximal matching needs "
            "Omega(n^2) queries even for randomized algorithms."
        ),
        failure_if_fixed=(
            "Same plant-off-the-samples class as R4; the recursion "
            "compounds the exposure (each level reruns the sampler). "
            "Deterministic route expectation unchanged: BG24 shape "
            "first (plan Task A5, [C])."
        ),
        limited_independence=(
            "Claims 3.3/3.4 are Chernoff + union bound: Theta(log n)-"
            "wise plausibly suffices [S]; recursion multiplies the "
            "number of seeds, not their required strength. SS4.2/SS5 "
            "details read at overview level only."
        ),
        evidence="AKK25 Lem 3.1, Claims 3.2-3.4, Lem 4.1; E5 (mechanism)",
        status="[V][M]",
    ),
    AuditRow(
        row_id="R6",
        papers="all five",
        mechanism=(
            "Whp amplification: union bounds over poly(n) updates / "
            "calls (explicit in BG24 Claim 8 and AKK25 Claims 3.3-3.4); "
            "fresh repetition where a single run succeeds with "
            "constant probability."
        ),
        buys="High-probability correctness, union-boundable over time.",
        failure_if_fixed=(
            "No deterministic analogue inside the probe interface "
            "(plan Lemma 3.6 kills the single run, so repetition "
            "cannot help); outside it, replacement = maintained "
            "deterministic summaries (plan WS-A)."
        ),
        limited_independence="Repetitions must be mutually independent.",
        evidence="Lemma 3.6; Cor 3.7",
        status="[P]",
    ),
    AuditRow(
        row_id="R7",
        papers="Beh23; BG24 (Prop. 5); AKK25 (Prop. 2.4); via Kis22",
        mechanism=(
            "Randomized vertex sparsification for the additive-to-"
            "multiplicative reduction: contract vertices into "
            "O(mu/eps) groups preserving (1-eps) of the matching, whp "
            "[AKLY16, AKL16, CCE+16] as implemented dynamically by "
            "Kis22. Verified statements: BKSW23 Prop. A.1 (App. A): "
            "'a randomized algorithm which for each update to G makes "
            "an update to O(log^2 n / eps^3) contracted subgraphs, "
            "such that w.h.p. ...'; AKK25 Prop. 2.4; BG24 Prop. 5; "
            "Beh23 SS1 (adaptive via [Kis22])."
        ),
        buys=(
            "Reduces vertex count to O(mu/eps), turning eps n-additive "
            "guarantees into (1-eps)-multiplicative with polylog "
            "overhead, whp, including against adaptive adversaries."
        ),
        failure_if_fixed=(
            "A fixed (published) contraction partition lets the "
            "adversary place the matching across collision classes, "
            "destroying preservation -- same plant-against-the-known-"
            "seed pattern as E5, one level up."
        ),
        limited_independence=(
            "Preservation proofs bound per-vertex collision events; "
            "pairwise independence gives the expectation, whp needs "
            "stronger tails. Kis22 full internals unread [M] (its "
            "operative form, BKSW23 Prop. A.1, is verified)."
        ),
        evidence="E5 (pattern); read-through pending for Kis22 lemmas",
        status="[V][M]",
    ),
    AuditRow(
        row_id="R8",
        papers="inventory row (not a randomness site)",
        mechanism=(
            "ALREADY-DETERMINISTIC layers, verified: McGregor boosting "
            "derandomized by Tir18 (explicit in AKK25 Prop. 2.2); "
            "greedy matching (AKK25 Fact 2.1, BG24 GreedyMatching); "
            "ORS charging (BG24 Lemma 11; AKK25 Lemma 2.5 -- its "
            "probabilistic method lives in the ANALYSIS only, no "
            "algorithmic coins); H_cert / G_old-G_batch-G_match "
            "bookkeeping (BG24 Alg 2; AKK25 Alg 2); Gupta-Peng "
            "bounded-degree (1+eps) maintenance (deterministic, cited "
            "e.g. BLM20 Lemma 6.1); the Gupta-Peng periodic-"
            "recomputation paradigm itself (BKSW23 JACM SS2); and -- "
            "notably -- ABR24 Thm 2: a DETERMINISTIC two-pass semi-"
            "streaming (2-sqrt2-eps)-approximation, showing the "
            "combinatorial core (maximal matching + duplicate-free "
            "b-matching + blossom-inequality analysis) is already "
            "deterministic under pass access; the dynamic version's "
            "coins are forced purely by the probe access model."
        ),
        buys="-- (no coins; listed to delimit the derandomization frontier)",
        failure_if_fixed="n/a",
        limited_independence="n/a",
        evidence=(
            "Frontier consequence: derandomizing BG24/AKK25 reduces to "
            "exactly three modules: the opportunistic sampler (R4/R5), "
            "the Beh21 estimator interface (R1; provably no probe "
            "drop-in), and vertex sparsification (R7). The sampler is "
            "a SEARCH problem with a promise -- outside Lemma 3.6's "
            "decision lower bound -- hence the genuinely open "
            "algorithmic target (refined Task A5)."
        ),
        status="[V]",
    ),
]


def evidence_index() -> dict[str, list[str]]:
    """Experiment id -> audit rows it supports (used by run_all summary)."""
    import re

    index: dict[str, list[str]] = {}
    for row in AUDIT_ROWS:
        for group in re.findall(r"\[E:([a-z0-9,\s]+)\]", row.status):
            for exp in group.split(","):
                index.setdefault(exp.strip(), []).append(row.row_id)
    return index
