# audit_lab run summary (Task A0)

Scale: `full`; seed: `20260611`.

| Exp | Supports audit rows | Headline numbers |
|---|---|---|
| E1 | R1 | err/n at s=6400: 0.0024; evals/query: 0.8; MM/mu min 0.805 |
| E2 | R2 | m=64000: fixed query = 64000 (= m: True), random mean = 1.8 |
| E3 | R2 | err/n full 0.0051 vs 2-wise 0.0051; path evals full 2.1 vs 2-wise 1.8 |
| E4 | R2 | recourse/update fixed 8000 vs random 1.20 (ratio 6667x) |
| E5 | R1, R4 | B=1127 (< C(n/2,2)=1128): det hits 0, plant 24, rand detect p=0.9933333333333333 |

## Interpretation (one line per experiment)

- **E1**: randomized sampling delivers the promised whp accuracy at O(1)-per-query locality (what R1/R2 randomness buys). [elapsed 4.99s]
- **E2**: a rank-aware adversary makes ONE oracle query cost exactly m evaluations under fixed ranks; random ranks keep it constant (failure mode of R2 if fixed). [elapsed 0.56s]
- **E3**: k-wise ranks (even k=2) empirically match fully-random accuracy and locality on oblivious instances -- input for Task A4; no theoretical claim. [elapsed 4.34s]
- **E4**: fixed-rank greedy suffers ~n recourse per update under head-edge toggling; random ranks absorb the same updates with O(1) mean recourse (dynamic failure mode of R2; supports plan Task A3(b)). [elapsed 1.07s]
- **E5**: with a fixed probe set the constructive adversary plants a size->=n/4 matching the detector never sees (0 hits): guaranteed below the Lemma 3.6 threshold C(ceil(n/2),2), and for THIS pseudorandom probe family it persists even at 90% of all pairs -- volume does not save a fixed probe set, only clique-structured coverage can. Fresh random probes with the same budget detect the plant whp (R1/R4 failure mode; Cor. 3.7 in action). [elapsed 0.78s]

## Audit rows (status snapshot)

- **R1** [V][P][E:e1,e5] -- Sublinear Monte-Carlo matching-size estimation via adjacency-matrix queries (Beh21). Verif...
- **R2** [V][M][E:e2,e3,e4] -- Uniformly random edge/vertex ranks driving greedy maximal matching: (a) inside the Beh21 e...
- **R3** [V][M] -- Adaptive-adversary robustness wrappers. Verified claims: BKSW23 abstract (adaptive + worst...
- **R4** [V][E:e5] -- RandomSampling (BG24 Algorithm 1, Lemma 7): per-vertex uniform sampling of candidate partn...
- **R5** [V][M] -- Opportunistic sublinear matcher (AKK25 Algorithm 1, Lemma 3.1): per-vertex neighbour sampl...
- **R6** [P] -- Whp amplification: union bounds over poly(n) updates / calls (explicit in BG24 Claim 8 and...
- **R7** [V][M] -- Randomized vertex sparsification for the additive-to-multiplicative reduction: contract ve...
- **R8** [V] -- ALREADY-DETERMINISTIC layers, verified: McGregor boosting derandomized by Tir18 (explicit ...
