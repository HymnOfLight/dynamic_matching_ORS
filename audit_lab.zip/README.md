# audit_lab — Task A0 (randomness audit) experimental package

Companion code for **Task 1 / A0** of the execution plan
*"Optimal Approximation for Fully Dynamic Matching and Ordered
Ruzsa–Szemerédi Graphs"* (§4, WS-A; code deliverable specified in §7,
WS-D). Pure Python 3.10+ standard library; matplotlib is optional
(plots only).

## What this package is

Task A0 asks for a table mapping **every random choice** in the
pipelines [BKSW23, Beh23, ABR24, BG24, AKK25] to:

1. the property it buys,
2. the failure mode if it is fixed (naively derandomised),
3. whether limited independence suffices.

This package delivers (a) the **machine-readable audit table**
(`auditlib/audit_table.py`, rendered to `results/audit_table.{tex,md}`)
and (b) five **seeded, reproducible experiments** that turn columns
(1)–(3) into measurements on a faithful model of the pipelines'
sublinear oracle layer (rank-driven greedy maximal matching + local
RGMM oracle + sampling estimator, after [Beh21]).

| Exp | Audit row | Question it answers | Full-scale headline (seed 20260611) |
|---|---|---|---|
| E1 | R1 | what sampling **buys** | err/n = 0.0024 at s=6400; 0.8 oracle evaluations/query; MM/μ ∈ [0.805, 1] (Blossom-checked) |
| E2 | R2 | **failure if ranks fixed** (locality) | one query = exactly *m* = 64 000 evaluations on the adversarial path; fully random ranks: mean 1.8 |
| E3 | R2/A4 | **limited independence** | 2-wise already matches fully-random accuracy (err/n 0.0051 = 0.0051) and locality — empirical input to Task A4, no theory claimed |
| E4 | R2 | **failure if ranks fixed** (dynamic recourse) | 8 000 recourse/update (full flip) vs 1.20 for random ranks (6 667×) — supports plan Task A3(b) |
| E5 | R1/R4 | **failure if samples fixed** | constructive adversary: plant of n/4 edges, 0 detector hits at every budget B < C(⌈n/2⌉,2); same-budget random probes detect with p = 0.993 — Lemma 3.6 / Cor. 3.7 in action |

Honesty tags follow the plan: `[V]` mechanism verified (plan §2.4),
`[M]` lemma-level reference pending the A0 read-through, `[P]` proved in
the plan, `[E:*]` empirical. **E3 and E5 are evidence, not theorems**:
E3 is purely empirical; E5 demonstrates the lemma's adversary against
one natural fixed-probe family (the lemma itself covers all
deterministic algorithms).

## Layout

```
audit_lab/
├── auditlib/
│   ├── graphs.py        # Graph type + generators (G(n,p) via geometric
│   │                    #   skips, paths, complement pairs)
│   ├── matching.py      # exact μ: Blossom (O(n^3)) cross-validated
│   │                    #   against bitmask DP; global greedy MM
│   ├── ranks.py         # rank sources: fully random / k-wise
│   │                    #   independent (poly over 2^61−1) / fixed
│   ├── rgmm.py          # iterative memoised local greedy-MM oracle
│   │                    #   (locality-instrumented) + estimators
│   ├── audit_table.py   # the A0 deliverable: machine-readable rows
│   ├── render.py        # → audit_table.tex (booktabs) / .md
│   └── experiments.py   # E1–E5
├── tests.py             # T1–T6 (see below)
├── run_all.py           # CLI orchestrator
└── results/             # generated: *.json, RESULTS.md, tables, plots
```

## Reproduce

```bash
python3 tests.py                      # 7 tests, <1 s
python3 run_all.py --scale quick      # ~3 s
python3 run_all.py --scale full       # ~12 s, regenerates results/
python3 run_all.py --only e2 e5       # subset
```

Everything is deterministic given `--seed` (default 20260611).

## Cross-validation (project methodology)

Every quantity entering a result is computed two independent ways:

- **T1**: Blossom vs bitmask-DP exact μ on 300 random graphs (n ≤ 14)
  plus odd cycles, Petersen, complete graphs — must agree exactly;
- **T2**: local oracle vs global greedy, edge-by-edge, under all three
  rank-source families (the oracle and the global algorithm share no
  code path);
- **T4/T5/T6**: the E2 adversarial cost (= m exactly), E5 plant
  validity (disjoint from probes, ≥ n/4 — the Lemma 3.6 guarantee), and
  E4 recourse arithmetic, each verified independently of the
  experiment code.

## v0.3 — read-through passes 1–2 (June 2026)

The audit table is now at **v0.2**: rows carry lemma-level locations
verified against arXiv full texts (BG24 v4 §1–4.4 read in full; AKK25
§1–4.1; BKSW23/Beh23/ABR24 at abstract + technique-overview level), two
new rows were added (R7 vertex sparsification; R8 the already-
deterministic inventory), and BG24's row was *narrowed*: the ORS
charging (Lemma 11) and certificate bookkeeping are deterministic — its
coins live only in Lemma 7's sampling plus the R1/R7 interfaces.
The companion technical note (`note/A0_note.tex`, compiled PDF
included) states the resulting **three-module deterministic frontier**
and the refined Task-A5 target (Problem 1: Det-Opportunistic-Matching).
Pass 2 added: Beh21 internals (Thm 3.5 over uniform π; the
rank-rotation obstruction φ(π,P⃗) for limited independence — Task A4
now has a precise obstacle vs. E3's empirical signal); ABR24 Thm 1
verified (adaptive, worst-case) + the RGMM-for-approximation nuance +
its **deterministic** two-pass streaming Thm 2; BKSW23 Prop A.1
(vertex sparsification = O(log²n/ε³) random contracted subgraphs,
whp); ACK19 resolved (SODA'19 Thm 6) and AS19 (ICALP'19 Thm 3,
deterministic Ω(n²) for *finding* MM) folded into C1 prior-art
scoping. The v0.3 table is also embedded in the plan document v1.1
(Appendix A). Remaining small [M]: BDHSS19/Sol16 maintenance
internals, BKSW23 §5+ robustness lemmas, Kis22 full text.

## Relation to the plan, and what comes next in A0

The experiments instantiate the audit's central conclusion (plan §2.4 →
Cor. 3.7): the pipelines' randomness concentrates at a probe-style
estimation interface that **provably has no deterministic drop-in
replacement**; derandomisation must move to *maintained* deterministic
structures (WS-A direction, crux Task A3). Remaining A0 work (2–3 week
budget) is the per-paper read-through that upgrades each `[M]` row to a
lemma-level citation and feeds the 4–6 page technical note rendered
from `audit_table.py`.

## Limitations

- The oracle layer is modelled after [Beh21]-style RGMM estimation;
  paper-specific kernel constructions (EDCS layers, ORS-epoch peeling)
  are audited at mechanism level (`[M]` rows), not re-implemented.
- E3's k-wise findings are empirical on oblivious instances; a
  rank-aware adversary against *known* k-wise coefficients is exactly
  the fixed-rank case (E2/E4) — see `ranks.FixedRanks` docstring.
- E5 extra finding: above the universal threshold the lemma no longer
  guarantees a plant, yet the *pseudorandom* fixed-probe family still
  fails at B = 90% of all pairs (complement of sparse-leftover pairs
  keeps a large matching). A deterministic probe set must spend its
  budget on clique-covering some ⌈n/2⌉ vertices, not on volume.
- Recourse in E4 is measured on recomputed greedy matchings
  (|M ⊕ M′|), i.e. an information bound, not a data-structure time.
