"""Task A0 orchestrator.

Usage
-----
    python3 run_all.py --scale quick            # CI-sized run (~1 min)
    python3 run_all.py --scale full             # report run (~5-10 min)
    python3 run_all.py --only e2 e5             # subset of experiments

Outputs (under ``results/``):
    e1.json .. e5.json      raw experiment results (seeded, reproducible)
    audit_table.tex/.md     rendered machine-readable audit table
    RESULTS.md              human-readable summary tying E* to audit rows
    *.png                   plots (only if matplotlib is available)
"""

from __future__ import annotations

import argparse
import json
import pathlib
import sys
import time

from auditlib.audit_table import AUDIT_ROWS, evidence_index
from auditlib.experiments import ALL_EXPERIMENTS
from auditlib.render import render_latex, render_markdown

RESULTS_DIR = pathlib.Path(__file__).parent / "results"


def run_experiments(names: list[str], seed: int, scale: str) -> dict[str, dict]:
    out: dict[str, dict] = {}
    for name in names:
        fn = ALL_EXPERIMENTS[name]
        t0 = time.perf_counter()
        print(f"[run] {name} (scale={scale}, seed={seed}) ...", flush=True)
        result = fn(seed=seed, scale=scale)
        result["elapsed_sec"] = round(time.perf_counter() - t0, 2)
        result["seed"] = seed
        result["scale"] = scale
        out[name] = result
        (RESULTS_DIR / f"{name}.json").write_text(
            json.dumps(result, indent=2, sort_keys=True)
        )
        print(f"[ok ] {name} in {result['elapsed_sec']}s")
    return out


def write_tables() -> None:
    (RESULTS_DIR / "audit_table.tex").write_text(render_latex())
    (RESULTS_DIR / "audit_table.md").write_text(render_markdown())
    print("[ok ] audit_table.tex / audit_table.md written")


def write_summary(results: dict[str, dict]) -> None:
    idx = evidence_index()
    lines = [
        "# audit_lab run summary (Task A0)",
        "",
        f"Scale: `{next(iter(results.values()))['scale']}`; "
        f"seed: `{next(iter(results.values()))['seed']}`.",
        "",
        "| Exp | Supports audit rows | Headline numbers |",
        "|---|---|---|",
    ]
    for name, r in results.items():
        head = _headline(name, r)
        lines.append(f"| {name.upper()} | {', '.join(idx.get(name, ['-']))} | {head} |")
    lines += ["", "## Interpretation (one line per experiment)", ""]
    lines += [f"- **{n.upper()}**: {_interpret(n, r)}" for n, r in results.items()]
    lines += [
        "",
        "## Audit rows (status snapshot)",
        "",
    ]
    lines += [f"- **{row.row_id}** {row.status} -- {row.mechanism[:90]}..."
              for row in AUDIT_ROWS]
    (RESULTS_DIR / "RESULTS.md").write_text("\n".join(lines) + "\n")
    print("[ok ] RESULTS.md written")


def _headline(name: str, r: dict) -> str:
    if name == "e1":
        grid = r["by_num_samples"]
        s_max = max(grid, key=int)
        return (
            f"err/n at s={s_max}: {grid[s_max]['mean_abs_err_over_n']:.4f}; "
            f"evals/query: {grid[s_max]['mean_evaluations_per_vertex_query']:.1f}; "
            f"MM/mu min {r['mm_over_mu_min']:.3f}"
        )
    if name == "e2":
        big = r["rows"][-1]
        return (
            f"m={big['m']}: fixed query = {big['fixed_rank_head_query_evaluations']}"
            f" (= m: {big['fixed_equals_m']}), random mean = "
            f"{big['random_rank_mean_evaluations']:.1f}"
        )
    if name == "e3":
        full = r["by_source"]["full"]
        k2 = r["by_source"]["2-wise"]
        return (
            f"err/n full {full['mean_abs_err_over_n']:.4f} vs 2-wise "
            f"{k2['mean_abs_err_over_n']:.4f}; path evals full "
            f"{full['path_mean_marginal_evaluations']:.1f} vs 2-wise "
            f"{k2['path_mean_marginal_evaluations']:.1f}"
        )
    if name == "e4":
        return (
            f"recourse/update fixed {r['fixed_rank_mean_recourse_per_update']:.0f}"
            f" vs random {r['random_rank_mean_recourse_per_update']:.2f}"
            f" (ratio {r['ratio_fixed_over_random']:.0f}x)"
        )
    if name == "e5":
        thr = r["params"]["lemma_threshold_C_ceil_n2_2"]
        at_thr = [row for row in r["rows"] if row["budget_B"] == thr - 1]
        row = at_thr[0] if at_thr else r["rows"][0]
        return (
            f"B={row['budget_B']} (< C(n/2,2)={thr}): det hits "
            f"{row['deterministic_detector_hits']}, plant {row['plant_size_used']}"
            f", rand detect p={row['randomized_detection_prob']}"
        )
    return ""


def _interpret(name: str, r: dict) -> str:
    texts = {
        "e1": "randomized sampling delivers the promised whp accuracy at "
              "O(1)-per-query locality (what R1/R2 randomness buys).",
        "e2": "a rank-aware adversary makes ONE oracle query cost exactly m "
              "evaluations under fixed ranks; random ranks keep it constant "
              "(failure mode of R2 if fixed).",
        "e3": "k-wise ranks (even k=2) empirically match fully-random "
              "accuracy and locality on oblivious instances -- input for "
              "Task A4; no theoretical claim.",
        "e4": "fixed-rank greedy suffers ~n recourse per update under "
              "head-edge toggling; random ranks absorb the same updates "
              "with O(1) mean recourse (dynamic failure mode of R2; "
              "supports plan Task A3(b)).",
        "e5": "with a fixed probe set the constructive adversary plants a "
              "size->=n/4 matching the detector never sees (0 hits): "
              "guaranteed below the Lemma 3.6 threshold C(ceil(n/2),2), "
              "and for THIS pseudorandom probe family it persists even at "
              "90% of all pairs -- volume does not save a fixed probe set, "
              "only clique-structured coverage can. Fresh random probes "
              "with the same budget detect the plant whp (R1/R4 failure "
              "mode; Cor. 3.7 in action).",
    }
    return texts[name] + f" [elapsed {r['elapsed_sec']}s]"


def maybe_plot(results: dict[str, dict]) -> None:
    try:
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
    except Exception:  # pragma: no cover - plotting is optional
        print("[..] matplotlib unavailable; skipping plots")
        return

    if "e2" in results:
        rows = results["e2"]["rows"]
        ms = [row["m"] for row in rows]
        fig, ax = plt.subplots(figsize=(5.2, 3.4))
        ax.plot(ms, [row["fixed_rank_head_query_evaluations"] for row in rows],
                "o-", label="fixed adversarial ranks")
        ax.plot(ms, [row["random_rank_mean_evaluations"] for row in rows],
                "s--", label="fully random ranks (mean)")
        ax.set_xscale("log"); ax.set_yscale("log")
        ax.set_xlabel("path edges m"); ax.set_ylabel("oracle evaluations / query")
        ax.set_title("E2: locality, fixed vs random ranks")
        ax.legend(); fig.tight_layout()
        fig.savefig(RESULTS_DIR / "e2_locality.png", dpi=150)
        plt.close(fig)

    if "e1" in results:
        grid = results["e1"]["by_num_samples"]
        ss = sorted(int(s) for s in grid)
        errs = [grid[str(s)]["mean_abs_err_over_n"]
                if str(s) in grid else grid[s]["mean_abs_err_over_n"] for s in ss]
        fig, ax = plt.subplots(figsize=(5.2, 3.4))
        ax.plot(ss, errs, "o-", label="measured |err|/n")
        ax.plot(ss, [errs[0] * (ss[0] / s) ** 0.5 for s in ss],
                ":", label=r"$\propto 1/\sqrt{s}$ reference")
        ax.set_xscale("log"); ax.set_yscale("log")
        ax.set_xlabel("samples s"); ax.set_ylabel("mean |estimate - |MM|| / n")
        ax.set_title("E1: estimator concentration")
        ax.legend(); fig.tight_layout()
        fig.savefig(RESULTS_DIR / "e1_concentration.png", dpi=150)
        plt.close(fig)
    print("[ok ] plots written (where applicable)")


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--scale", choices=["quick", "full"], default="quick")
    parser.add_argument("--seed", type=int, default=20260611)
    parser.add_argument("--only", nargs="*", choices=sorted(ALL_EXPERIMENTS),
                        default=sorted(ALL_EXPERIMENTS))
    args = parser.parse_args(argv)

    RESULTS_DIR.mkdir(exist_ok=True)
    results = run_experiments(args.only, seed=args.seed, scale=args.scale)
    write_tables()
    write_summary(results)
    maybe_plot(results)
    print("[done] see results/RESULTS.md")
    return 0


if __name__ == "__main__":
    sys.exit(main())
